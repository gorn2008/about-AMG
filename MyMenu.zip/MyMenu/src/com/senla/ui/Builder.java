package com.senla.ui;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

//import com.senla.properties.PropertyUtility;
import com.senla.ui.action.guest.AddGuestAction;
import com.senla.ui.action.guest.ExportGuestsToCSVAction;
import com.senla.ui.action.guest.ImportGuestsFromCSVAction;
import com.senla.ui.action.guest.ShowGuestPaymentAction;
import com.senla.ui.action.guest.ShowGuestsAndTheyRoomsSortedByAlphabetAction;
import com.senla.ui.action.guest.ShowGuestsAndTheyRoomsSortedByDateToAction;
import com.senla.ui.action.guest.ShowGuestsQuantityAction;
import com.senla.ui.action.room.AddRoomAction;
import com.senla.ui.action.room.ChangeRoomPriceAction;
import com.senla.ui.action.room.ChangeRoomStatusToRepairingAction;
import com.senla.ui.action.room.ChangeRoomStatusToServicedAction;
import com.senla.ui.action.room.CloneRoomAction;
import com.senla.ui.action.room.EvictGuestAction;
import com.senla.ui.action.room.ExportRoomsToCSVAction;
import com.senla.ui.action.room.ImportRoomsFromCSVAction;
import com.senla.ui.action.room.SettleGuestAction;
import com.senla.ui.action.room.ShowFreeRoomsOnDateAction;
import com.senla.ui.action.room.ShowFreeRoomsQuantityAction;
import com.senla.ui.action.room.ShowFreeRoomsSortedByCapacityAction;
import com.senla.ui.action.room.ShowFreeRoomsSortedByPriceAction;
import com.senla.ui.action.room.ShowFreeRoomsSortedByStarsAction;
import com.senla.ui.action.room.ShowRoomDetailsAction;
import com.senla.ui.action.room.ShowRoomsPricesSortedByPriceAction;
import com.senla.ui.action.room.ShowRoomsPricesSortedByVIPAction;
import com.senla.ui.action.room.ShowRoomsSortedByCapacityAction;
import com.senla.ui.action.room.ShowRoomsSortedByPriceAction;
import com.senla.ui.action.room.ShowRoomsSortedByStarsAction;
import com.senla.ui.action.room.ShowLastGuestsAction;
import com.senla.ui.action.service.AddServiceAction;
import com.senla.ui.action.service.ChangeServicePriceAction;
import com.senla.ui.action.service.ExportServicesToCSVAction;
import com.senla.ui.action.service.ImportServicesFromCSVAction;
import com.senla.ui.action.service.ShowGuestServicesWithPricesSortedByDateAction;
import com.senla.ui.action.service.ShowGuestServicesWithPricesSortedByPriceAction;
import com.senla.ui.action.service.ShowServicesPricesSortedByPriceAction;
import com.senla.ui.action.service.ShowServicesPricesSortedByVIPAction;

public class Builder {
	private static final Logger LOG = LogManager.getLogger(Builder.class);
	private Menu rootMenu;
	
	public Menu getRootMenu() {
		return rootMenu;
	}
	
	public void buildMenu() {	
		rootMenu = new Menu("Main menu");		
		//Boolean showChangeStatusMenu = PropertyUtility.getBooleanProperty("status.change.show");		
		
		Menu roomMenu = new Menu("Rooms menu");
		
		MenuItem rooms = new MenuItem("Rooms", null);
		rooms.setNextMenu(roomMenu);
		
		MenuItem roomsSortedByPrice = new MenuItem("Show rooms sorted by price.",
				new ShowRoomsSortedByPriceAction(), roomMenu);
		roomMenu.addMenuItem(roomsSortedByPrice);

		MenuItem roomsSortedByCapacity = new MenuItem("Show rooms sorted by capacity.",
				new ShowRoomsSortedByCapacityAction(), roomMenu);
		roomMenu.addMenuItem(roomsSortedByCapacity);
		
		MenuItem roomsSortedByStars = new MenuItem("Show rooms sorted by number of stars.",
				new ShowRoomsSortedByStarsAction(), roomMenu);
		roomMenu.addMenuItem(roomsSortedByStars);
		
		MenuItem freeRoomsSortedByPrice = new MenuItem("Show free rooms sorted by price.",
				new ShowFreeRoomsSortedByPriceAction(), roomMenu);
		roomMenu.addMenuItem(freeRoomsSortedByPrice);
		
		MenuItem freeRoomsSortedByCapacity = new MenuItem("Show free rooms sorted by capacity.",
				new ShowFreeRoomsSortedByCapacityAction(), roomMenu);
		roomMenu.addMenuItem(freeRoomsSortedByCapacity);
		
		MenuItem freeRoomsSortedByStars = new MenuItem("Show free rooms sorted by number of stars.",
				new ShowFreeRoomsSortedByStarsAction(), roomMenu);
		roomMenu.addMenuItem(freeRoomsSortedByStars);
		
		MenuItem freeRoomsOnDate = new MenuItem("Show free rooms on future date.",
				new ShowFreeRoomsOnDateAction(), roomMenu);
		roomMenu.addMenuItem(freeRoomsOnDate);
		
		MenuItem freeRoomsQuantity = new MenuItem("Show number of free rooms.",
				new ShowFreeRoomsQuantityAction(), roomMenu);
		roomMenu.addMenuItem(freeRoomsQuantity);
		
		MenuItem roomsPricesSortedByVIP = new MenuItem("Show prices of rooms sorted by VIP.",
				new ShowRoomsPricesSortedByVIPAction(), roomMenu);
		roomMenu.addMenuItem(roomsPricesSortedByVIP);
		
		MenuItem roomsPricesSortedByPrice = new MenuItem("Show prices of rooms sorted by price.",
				new ShowRoomsPricesSortedByPriceAction(), roomMenu);
		roomMenu.addMenuItem(roomsPricesSortedByPrice);
		
		MenuItem showRoomDetails = new MenuItem("Show details of the room.",
				new ShowRoomDetailsAction(), roomMenu);
		roomMenu.addMenuItem(showRoomDetails);
		
		MenuItem settleGuest = new MenuItem("Settle guest to the room.",
				new SettleGuestAction(), roomMenu);
		roomMenu.addMenuItem(settleGuest);
		
		MenuItem evictGuest = new MenuItem("Evict guest from room.",
				new EvictGuestAction(), roomMenu);
		roomMenu.addMenuItem(evictGuest);
		
		MenuItem showLastGuests = new MenuItem("Show last guests of the room.",
				new ShowLastGuestsAction(), roomMenu);
		roomMenu.addMenuItem(showLastGuests);
		
		//if (showChangeStatusMenu) {
			MenuItem changeRoomStatusToRepairing = new MenuItem("Change room status to repairing.",
					new ChangeRoomStatusToRepairingAction(), roomMenu);
			roomMenu.addMenuItem(changeRoomStatusToRepairing);

			MenuItem changeRoomStatusToServiced = new MenuItem("Change room status to serviced.",
					new ChangeRoomStatusToServicedAction(), roomMenu);
			roomMenu.addMenuItem(changeRoomStatusToServiced);
		//}
		
		MenuItem changeRoomPrice = new MenuItem("Change room price.",
				new ChangeRoomPriceAction(), roomMenu);
		roomMenu.addMenuItem(changeRoomPrice);
		
		MenuItem cloneRoom = new MenuItem("Clone room.",new CloneRoomAction(), roomMenu);
		roomMenu.addMenuItem(cloneRoom);		

		MenuItem addRoom = new MenuItem("Add room.",new AddRoomAction(), roomMenu);
		roomMenu.addMenuItem(addRoom);
		
		/*MenuItem importRooms = new MenuItem("Import rooms from CSV.",new ImportRoomsFromCSVAction(), roomMenu);
		roomMenu.addMenuItem(importRooms);*/
		
		MenuItem exportRooms = new MenuItem("Export rooms to CSV.",new ExportRoomsToCSVAction(), roomMenu);
		roomMenu.addMenuItem(exportRooms);
		
		roomMenu.addMenuItem(new MenuItem("Return to main menu.", null, rootMenu));
		
		
		
		Menu guestMenu = new Menu("Guests menu");		
		MenuItem guests = new MenuItem("Guests", null, guestMenu);
		guestMenu.addMenuItem(new MenuItem("Show guests and their rooms sorted by alphabet.",
				new ShowGuestsAndTheyRoomsSortedByAlphabetAction(), guestMenu));
		guestMenu.addMenuItem(new MenuItem("Show guests and their rooms sorted by date when they will vacate room.",
				new ShowGuestsAndTheyRoomsSortedByDateToAction(), guestMenu));
		guestMenu.addMenuItem(new MenuItem("Show overall number of guests.",
				new ShowGuestsQuantityAction(), guestMenu));
		guestMenu.addMenuItem(new MenuItem("Show guest payment for the room.",
				new ShowGuestPaymentAction(), guestMenu));
		guestMenu.addMenuItem(new MenuItem("Add guest.",
				new AddGuestAction(), guestMenu));
		/*guestMenu.addMenuItem(new MenuItem("Import guests from CSV.",
				new ImportGuestsFromCSVAction(), guestMenu));*/
		guestMenu.addMenuItem(new MenuItem("Export guests to CSV.",
				new ExportGuestsToCSVAction(), guestMenu));
		guestMenu.addMenuItem(new MenuItem("Return to main menu.", null, rootMenu));
		
		
		Menu servicesMenu = new Menu("Services menu");
		
		MenuItem services = new MenuItem("Services", null, servicesMenu);
		
		servicesMenu.addMenuItem(new MenuItem("Show prices of services sorted by price.",
				new ShowServicesPricesSortedByPriceAction(), servicesMenu));
		servicesMenu.addMenuItem(new MenuItem("Show prices of services sorted by VIP.",
				new ShowServicesPricesSortedByVIPAction(), servicesMenu));
		
		servicesMenu.addMenuItem(new MenuItem("Show guest services with prices sorted by price.",
				new ShowGuestServicesWithPricesSortedByPriceAction(), servicesMenu));
		
		servicesMenu.addMenuItem(new MenuItem("Show guest services with prices sorted by date.",
				new ShowGuestServicesWithPricesSortedByDateAction(), servicesMenu));
		
		servicesMenu.addMenuItem(new MenuItem("Change service price.", 
				new ChangeServicePriceAction(), servicesMenu));
		
		servicesMenu.addMenuItem(new MenuItem("Add service.", 
				new AddServiceAction(), servicesMenu));
		
		/*servicesMenu.addMenuItem(new MenuItem("Import services from CSV.", 
				new ImportServicesFromCSVAction(), servicesMenu));*/
		
		servicesMenu.addMenuItem(new MenuItem("Export services to CSV.", 
				new ExportServicesToCSVAction(), servicesMenu));
		servicesMenu.addMenuItem(new MenuItem("Return to main menu.", null, rootMenu));
		
		
		rootMenu.addMenuItem(rooms);
		rootMenu.addMenuItem(guests);
		rootMenu.addMenuItem(services);
	
	}
}
