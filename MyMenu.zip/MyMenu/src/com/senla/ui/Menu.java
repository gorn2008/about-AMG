package com.senla.ui;

import java.util.ArrayList;
import java.util.List;

public class Menu {
	private String name;
	private List<MenuItem> menuItems;
	
	public Menu () {
		menuItems = new ArrayList<MenuItem>();
	}
	public Menu(String name) {
		this.name = name;
		menuItems = new ArrayList<MenuItem>();
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<MenuItem> getMenuItems() {
		return menuItems;
	}
	public void setMenuItems(List<MenuItem> menuItems) {
		this.menuItems = menuItems;
	}
	
	public void addMenuItem(MenuItem mi) {
		menuItems.add(mi);
	}
	
}
