package com.senla.ui;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.senla.ui.util.ScannerUtility;

import api.core.server.Request;
import api.core.util.ClientUtility;
import api.core.util.Printer;

public class MenuController {
	private static final Logger LOG = LogManager.getLogger(MenuController.class);
	private Builder builder;
	private Navigator navigator;
	private Socket socket;

	public MenuController(Socket socket) {
		this.socket = socket;
	}
	
	public void run() {
		builder = new Builder();
		builder.buildMenu();
		try {
			ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
			ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
			ClientUtility.setOut(out);
			ClientUtility.setIn(in);
		} catch (IOException e) {
			LOG.error(e);
		}
		navigator = new Navigator();
		navigator.setCurrentMenu(builder.getRootMenu());
		navigator.printMenu();
		Integer index;
		while (true) {
			String input = ScannerUtility.getString();
			if ("exit".equals(input)) {
				Request req = new Request();
				req.setMethodName("exit");
				ClientUtility.sendRequest(req);
				ClientUtility.closeStreams();
				try {
					this.socket.close();
				} catch (IOException e) {
					LOG.error(e);
				}
				break;
			}
			index = -1;
			try {
				index = Integer.parseInt(input);
			} catch (NumberFormatException e) {
				LOG.error("String was entered instead of number of menu item.");
			}
			if (index > 0 && 
					index <= navigator.getCurrentMenu().getMenuItems().size()) {
				navigator.getCurrentMenu().getMenuItems().get(index-1).doAction();
				navigator.navigate(index-1);
				navigator.printMenu();
			} else {
				Printer.printMessage("Choose menu item via entering its number.");
			}
			
		}
		ScannerUtility.closeScanner();
	}
	
}
