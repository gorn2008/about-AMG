package com.senla.ui;

import com.senla.ui.action.IAction;

public class MenuItem {
	private String title;
	private IAction action;
	private Menu nextMenu;
	
	public void doAction() {
		if (action != null) {
			action.execute();
		}
	}	
	
	public MenuItem (String title, IAction action) {
		this.title = title;
		this.action = action;
		if (action == null) {
			this.nextMenu = null;
		}
	}
	
	public MenuItem (String title, IAction action, Menu nextMenu) {
		this.title = title;
		this.action = action;
		this.nextMenu = nextMenu;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public IAction getAction() {
		return action;
	}

	public void setAction(IAction action) {
		this.action = action;
	}

	public Menu getNextMenu() {
		return nextMenu;
	}

	public void setNextMenu(Menu nextMenu) {
		this.nextMenu = nextMenu;
	}	
	
	
}
