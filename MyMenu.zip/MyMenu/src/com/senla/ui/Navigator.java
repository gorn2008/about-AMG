package com.senla.ui;

import api.core.util.Printer;

public class Navigator {
	private Menu currentMenu;	
	
	public Menu getCurrentMenu() {
		return currentMenu;
	}

	public void setCurrentMenu(Menu currentMenu) {
		this.currentMenu = currentMenu;
	}

	public void printMenu() {
		
		Printer.printMessage(currentMenu.getName());
		int i = 1;
		for(MenuItem mi: currentMenu.getMenuItems()) {
			Printer.printMessage(i + "." + mi.getTitle());
			i++;
		}
		
	}
	
	public void navigate(Integer index) {
		currentMenu = currentMenu.getMenuItems().get(index).getNextMenu();
	}
}
