package com.senla.ui.action;


public abstract class AbstractAction implements IAction {
	//public IController controller = (IController)DependencyInjection.getClassInstance(IController.class);

}
