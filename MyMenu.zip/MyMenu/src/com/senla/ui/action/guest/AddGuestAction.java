package com.senla.ui.action.guest;


import com.senla.ui.action.AbstractAction;
import com.senla.ui.util.ScannerUtility;

import api.core.model.Guest;
import api.core.server.Request;
import api.core.util.ClientUtility;
import api.core.util.Printer;

public class AddGuestAction extends AbstractAction {

	public void execute() {
		Guest guest = new Guest();
		Printer.printMessage("Enter guest number");		
		guest.setGuestNumber(ScannerUtility.getInteger());
		
		Printer.printMessage("Enter guest name");
		guest.setName(ScannerUtility.getString());
		
		Printer.printMessage("Enter guest surname");	
		guest.setSurname(ScannerUtility.getString());
		
		Request request = new Request();
		request.setMethodName("addGuest");
		Object[] params = {guest};
		request.setParams(params);
		ClientUtility.sendRequest(request);
		
		//controller.addGuest(guest);
	}

}
