package com.senla.ui.action.guest;

import com.senla.ui.action.AbstractAction;

import api.core.server.Request;
import api.core.util.ClientUtility;

public class ExportGuestsToCSVAction extends AbstractAction{

	public void execute() {
		//controller.exportGuestsToCSV();
		Request request = new Request();
		request.setMethodName("exportGuestsToCSV");
		request.setParams(null);
		ClientUtility.sendRequest(request);

	}
	

}
