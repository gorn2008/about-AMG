package com.senla.ui.action.guest;

import com.senla.ui.action.AbstractAction;

import api.core.server.Request;
import api.core.util.ClientUtility;

public class ImportGuestsFromCSVAction extends AbstractAction{

	public void execute() {
		//controller.importGuestsFromCSV();
		Request request = new Request();
		request.setMethodName("importGuestsFromCSV");
		request.setParams(null);
		ClientUtility.sendRequest(request);
	}

}
