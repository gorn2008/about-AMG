package com.senla.ui.action.guest;

import com.senla.ui.action.AbstractAction;
import com.senla.ui.util.ScannerUtility;

import api.core.server.Request;
import api.core.server.Response;
import api.core.util.ClientUtility;
import api.core.util.Printer;

public class ShowGuestPaymentAction extends AbstractAction {

	public void execute() {
		Printer.printMessage("Enter guest number");
		Integer guestNumber = ScannerUtility.getInteger();

		Request request = new Request();
		request.setMethodName("getGuestPayment");
		Object[] params = { guestNumber };
		request.setParams(params);
		Response response = ClientUtility.sendRequest(request);
		if (response.getResult() == null) {
			Printer.printMessage("This guest should not pay anything");
			return;
		}

		Double payment = (Double) response.getResult();
		Printer.printMessage("Guest number " + guestNumber + " should pay for his number " + payment);

	}

}
