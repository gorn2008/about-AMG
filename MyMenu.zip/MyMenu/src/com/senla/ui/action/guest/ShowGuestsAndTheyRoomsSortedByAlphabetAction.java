package com.senla.ui.action.guest;

import java.util.List;
import com.senla.ui.action.AbstractAction;

import api.core.model.Guest;
import api.core.server.Request;
import api.core.server.Response;
import api.core.util.ClientUtility;
import api.core.util.Printer;

public class ShowGuestsAndTheyRoomsSortedByAlphabetAction extends AbstractAction{

	public void execute() {
		//List<Guest> guests = controller.getGuestsAndTheyRoomsSortedByAlphabet();
		
		Request request = new Request();
		request.setMethodName("getGuestsAndTheyRoomsSortedByAlphabet");
		request.setParams(null);
		Response response = ClientUtility.sendRequest(request);
		
		if (response.getResult() == null) {
			return;
		}
		List<Guest> guests = (List<Guest>) response.getResult();
		
		for (Guest guest : guests) {
			if (guest.getRoomNumber() != null) {
				Printer.printGuest(guest);
				Printer.printMessage("is staying at room number " + 
						guest.getRoomNumber());
				Printer.printMessage("---");
			}				
		}
		
	}

}
