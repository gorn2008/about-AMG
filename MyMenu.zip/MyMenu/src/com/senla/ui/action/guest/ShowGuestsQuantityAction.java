package com.senla.ui.action.guest;

import com.senla.ui.action.AbstractAction;

import api.core.server.Request;
import api.core.server.Response;
import api.core.util.ClientUtility;
import api.core.util.Printer;

public class ShowGuestsQuantityAction extends AbstractAction {

	public void execute() {
		
		Request request = new Request();
		request.setMethodName("getGuestsQuantity");			
		request.setParams(null);		
		Response response = ClientUtility.sendRequest(request);
		if (response.getResult() == null) {
			Printer.printMessage("There is no guests in the hotel");
			return;
		}
		Integer guestsQuantity = (Integer) response.getResult();
		
		//Integer guestsQuantity = controller.getGuestsQuantity();
		Printer.printMessage("In hotel stays " + guestsQuantity + " guests");
		
	}
			

}
