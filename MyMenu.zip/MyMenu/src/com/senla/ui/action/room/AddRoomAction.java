package com.senla.ui.action.room;

import com.senla.ui.action.AbstractAction;
import com.senla.ui.util.ScannerUtility;

import api.core.model.Room;
import api.core.server.Request;
import api.core.util.ClientUtility;
import api.core.util.Printer;

public class AddRoomAction extends AbstractAction {

	public void execute() {		
		Room room = new Room();
		Printer.printMessage("Enter room number");
		room.setRoomNumber(ScannerUtility.getInteger());
		
		Printer.printMessage("Enter room capacity");		
		room.setCapacity(ScannerUtility.getInteger());
		
		Printer.printMessage("Enter if room is VIP(true/false)");		
		room.setVip(ScannerUtility.getBoolean());
		
		Printer.printMessage("Enter room price");		
		room.setPrice(ScannerUtility.getDouble());
		
		Printer.printMessage("Enter room star number");	
		room.setStarNumber(ScannerUtility.getByte());
		
		//controller.addRoom(room);
		
		Request request = new Request();
		request.setMethodName("addRoom");
		Object[] params = {room};
		request.setParams(params);
		ClientUtility.sendRequest(request);
		
	}
}
