package com.senla.ui.action.room;


import com.senla.ui.action.AbstractAction;
import com.senla.ui.util.ScannerUtility;

import api.core.server.Request;
import api.core.util.ClientUtility;
import api.core.util.Printer;

public class ChangeRoomPriceAction extends AbstractAction {

	public void execute() {
		Printer.printMessage("Enter room number");
		Integer roomNumber = ScannerUtility.getInteger();		
		
		Printer.printMessage("Enter new room price");
		Double newPrice = ScannerUtility.getDouble();
		
		Request request = new Request();
		request.setMethodName("changeRoomPrice");
		Object[] params = {roomNumber, newPrice};
		request.setParams(params);
		ClientUtility.sendRequest(request);
		
		//controller.changeRoomPrice(roomNumber, newPrice);
	}
	
}
