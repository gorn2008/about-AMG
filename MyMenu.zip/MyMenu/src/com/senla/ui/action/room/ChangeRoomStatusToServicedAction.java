package com.senla.ui.action.room;

import com.senla.ui.action.AbstractAction;
import com.senla.ui.util.ScannerUtility;

import api.core.server.Request;
import api.core.util.ClientUtility;
import api.core.util.Printer;

public class ChangeRoomStatusToServicedAction extends AbstractAction {

	public void execute() {
		Printer.printMessage("Enter room number");
		//controller.changeRoomStatusToServiced(ScannerUtility.getInteger());
		Integer roomNumber = ScannerUtility.getInteger();
		Request request = new Request();
		request.setMethodName("changeRoomStatusToServiced");
		Object[] params = {roomNumber};
		request.setParams(params);
		ClientUtility.sendRequest(request);
	}

}
