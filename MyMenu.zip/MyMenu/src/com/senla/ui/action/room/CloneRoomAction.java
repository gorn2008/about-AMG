package com.senla.ui.action.room;

import com.senla.ui.action.AbstractAction;
import com.senla.ui.util.ScannerUtility;

import api.core.model.Room;
import api.core.server.Request;
import api.core.server.Response;
import api.core.util.ClientUtility;
import api.core.util.Printer;

public class CloneRoomAction extends AbstractAction {

	public void execute() {
		Printer.printMessage("Enter room number");
		Integer roomNumber = ScannerUtility.getInteger();
								
		Request request = new Request();
		request.setMethodName("cloneRoom");
		Object[] params = {roomNumber};
		request.setParams(params);
		Response response = ClientUtility.sendRequest(request);
		if (response.getResult() == null) {
			return;
		}
		
		//Room room = controller.cloneRoom(ScannerUtility.getInteger());
		Room room = (Room) response.getResult();
		Printer.printMessage("Details of new room:");
		Printer.printRoom(room);
		Printer.printMessage("Do you want to modify it? yes/no");

		if ("yes".equals(ScannerUtility.getString())) {
			Printer.printMessage("Enter room capacity");
			room.setCapacity(ScannerUtility.getInteger());

			Printer.printMessage("Enter if room is VIP(true/false)");
			room.setVip(ScannerUtility.getBoolean());

			Printer.printMessage("Enter room price");
			room.setPrice(ScannerUtility.getDouble());

			Printer.printMessage("Enter room star number");
			room.setStarNumber(ScannerUtility.getByte());
		}
		Request request2 = new Request();
		request2.setMethodName("addRoom");
		params = new Object[] {room};
		request2.setParams(params);
		ClientUtility.sendRequest(request2);
		//controller.addRoom(room);
	}

}
