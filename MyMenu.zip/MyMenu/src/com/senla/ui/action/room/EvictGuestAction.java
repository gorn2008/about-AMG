package com.senla.ui.action.room;

import com.senla.ui.action.AbstractAction;
import com.senla.ui.util.ScannerUtility;

import api.core.server.Request;
import api.core.util.ClientUtility;
import api.core.util.Printer;

public class EvictGuestAction extends AbstractAction {

	public void execute() {
		Printer.printMessage("Enter room number");
		Integer roomNumber = ScannerUtility.getInteger();
		
		Printer.printMessage("Enter guest number");
		Integer guestNumber = ScannerUtility.getInteger();
		
		Request request = new Request();
		request.setMethodName("evictGuest");
		Object[] params = {roomNumber, guestNumber};
		request.setParams(params);
		ClientUtility.sendRequest(request);
		
		//controller.evictGuest(roomNumber, guestNumber);
	}

}
