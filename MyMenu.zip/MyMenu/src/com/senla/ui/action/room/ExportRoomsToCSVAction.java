package com.senla.ui.action.room;

import com.senla.ui.action.AbstractAction;
import api.core.server.Request;
import api.core.util.ClientUtility;


public class ExportRoomsToCSVAction extends AbstractAction {

	public void execute() {
		//controller.exportRoomsToCSV();
		Request request = new Request();
		request.setMethodName("exportRoomsToCSV");
		request.setParams(null);
		ClientUtility.sendRequest(request);
	}

}
