package com.senla.ui.action.room;

import com.senla.ui.action.AbstractAction;

import api.core.server.Request;
import api.core.util.ClientUtility;

public class ImportRoomsFromCSVAction extends AbstractAction {

	public void execute() {
		//controller.importRoomsFromCSV();
		Request request = new Request();
		request.setMethodName("importRoomsFromCSV");
		request.setParams(null);
		ClientUtility.sendRequest(request);
		
	}

}
