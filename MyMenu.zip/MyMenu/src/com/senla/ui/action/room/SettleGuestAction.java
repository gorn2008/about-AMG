package com.senla.ui.action.room;

import java.util.Date;

import com.senla.ui.action.AbstractAction;
import com.senla.ui.util.ScannerUtility;

import api.core.server.Request;
import api.core.util.ClientUtility;
import api.core.util.Printer;


public class SettleGuestAction extends AbstractAction {

	public void execute() {		
		Printer.printMessage("Enter room number");		
		Integer roomNumber = ScannerUtility.getInteger();
		
		Printer.printMessage("Enter guest number");	
		Integer guestNumber = ScannerUtility.getInteger();
		
		Printer.printMessage("Enter beginning of stay date (dd-MM-yyyy)");
		Date dateFrom = ScannerUtility.getDate();
		
		Printer.printMessage("Enter end of stay date (dd-MM-yyyy)");
		Date dateTo = ScannerUtility.getDate();
		
		
		Request request = new Request();
		request.setMethodName("settleGuest");
		Object[] params = {roomNumber, guestNumber, dateFrom, dateTo};
		request.setParams(params);
		ClientUtility.sendRequest(request);
		
		
		//controller.settleGuest(roomNumber, guestNumber, dateFrom, dateTo);	
		
	}

}
