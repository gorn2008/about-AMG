package com.senla.ui.action.room;

import java.util.Date;
import java.util.List;
import com.senla.ui.action.AbstractAction;
import com.senla.ui.util.ScannerUtility;

import api.core.model.Room;
import api.core.server.Request;
import api.core.server.Response;
import api.core.util.ClientUtility;
import api.core.util.Printer;

public class ShowFreeRoomsOnDateAction extends AbstractAction {

	public void execute() {
		Printer.printMessage("Enter date (dd-MM-yyyy)");
		Date date = ScannerUtility.getDate();
		
		Request request = new Request();
		request.setMethodName("getFreeRoomsOnDate");		
		Object[] params = {date};		
		request.setParams(params);		
		Response response = ClientUtility.sendRequest(request);
		if (response.getResult() == null) {
			return;
		}
		
		//List<Room> rooms = controller.getFreeRoomsOnDate(date);
		List<Room> rooms = (List<Room>) response.getResult();
		if (rooms.size() == 0){
			return;
		}
		Printer.printMessage("List of free rooms on date:" + date);
		for (Room room : rooms) {
			Printer.printRoomShort(room);
		}
	}

}
