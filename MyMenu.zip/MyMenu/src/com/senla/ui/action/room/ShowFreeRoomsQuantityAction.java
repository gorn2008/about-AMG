package com.senla.ui.action.room;

import com.senla.ui.action.AbstractAction;

import api.core.server.Request;
import api.core.server.Response;
import api.core.util.ClientUtility;
import api.core.util.Printer;

public class ShowFreeRoomsQuantityAction extends AbstractAction {

	public void execute() {
		//Integer freeRoomsQuantity = controller.getFreeRoomsQuantity();
		Request request = new Request();
		request.setMethodName("getFreeRoomsQuantity");
		request.setParams(null);		
		Response response = ClientUtility.sendRequest(request);
		if (response.getResult() == null) {
			return;
		}
		Integer freeRoomsQuantity = (Integer) response.getResult();
		Printer.printMessage("Number of free rooms:" + freeRoomsQuantity);	
	}

}
