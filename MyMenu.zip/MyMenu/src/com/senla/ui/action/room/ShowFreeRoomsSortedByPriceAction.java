package com.senla.ui.action.room;

import java.util.List;

import com.senla.ui.action.AbstractAction;

import api.core.model.Room;
import api.core.server.Request;
import api.core.server.Response;
import api.core.util.ClientUtility;
import api.core.util.Printer;

public class ShowFreeRoomsSortedByPriceAction extends AbstractAction{

	public void execute() {
		Request request = new Request();
		request.setMethodName("getFreeRoomsSortedByPrice");
		request.setParams(null);
		Response response = ClientUtility.sendRequest(request);

		if (response.getResult() == null) {
			return;
		}
		Printer.printMessage("List of free rooms sorted by price:");
		List<Room> rooms = (List<Room>) response.getResult();
		for (Room room : rooms) {
			Printer.printRoom(room);
		}/*
		Printer.printMessage("List of free rooms sorted by price:");
		List<Room> rooms = controller.getFreeRoomsSortedByPrice();
		if (rooms == null) {
			return;
		}		
		for (Room room:rooms) {
			Printer.printRoom(room);
		}*/
	}

}
