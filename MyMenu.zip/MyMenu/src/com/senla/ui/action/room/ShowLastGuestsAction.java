package com.senla.ui.action.room;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.senla.ui.action.AbstractAction;
import com.senla.ui.util.ScannerUtility;

import api.core.model.Guest;
import api.core.server.Request;
import api.core.server.Response;
import api.core.util.ClientUtility;
import api.core.util.Printer;

public class ShowLastGuestsAction extends AbstractAction {
	private static final Logger LOG = LogManager.getLogger(ShowLastGuestsAction.class);

	public void execute() {
		Printer.printMessage("Enter room number");
		Integer roomNumber = ScannerUtility.getInteger();		
		
		Request request = new Request();
		request.setMethodName("getLastGuests");		
		Object[] params = {roomNumber};		
		request.setParams(params);		
		Response response = ClientUtility.sendRequest(request);
		if (response.getResult() == null) {
			return;
		}
		Printer.printMessage("Last guests of the room are following:");
		List<Guest> lastGuests = (List<Guest>) response.getResult();
		for (Guest guest : lastGuests) {
			Printer.printGuestWithDates(guest);
		}
	}
}
