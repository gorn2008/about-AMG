package com.senla.ui.action.room;


import com.senla.ui.action.AbstractAction;
import com.senla.ui.util.ScannerUtility;

import api.core.model.Room;
import api.core.server.Request;
import api.core.server.Response;
import api.core.util.ClientUtility;
import api.core.util.Printer;

public class ShowRoomDetailsAction extends AbstractAction {

	public void execute() {
		Printer.printMessage("Enter room number");
		
		Request request = new Request();
		request.setMethodName("getRoom");
		Integer roomNumber = ScannerUtility.getInteger();
		Object[] params = {roomNumber};		
		request.setParams(params);		
		Response response = ClientUtility.sendRequest(request);
		
		Room room = (Room) response.getResult();
		
		//Room room = controller.getRoom(ScannerUtility.getInteger());
		Printer.printRoom(room);
	}
	

}
