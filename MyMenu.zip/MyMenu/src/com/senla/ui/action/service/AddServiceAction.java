package com.senla.ui.action.service;


import com.senla.ui.action.AbstractAction;
import com.senla.ui.util.ScannerUtility;

import api.core.model.Service;
import api.core.server.Request;
import api.core.util.ClientUtility;
import api.core.util.Printer;

public class AddServiceAction extends AbstractAction {

	public void execute() {
		Service service = new Service();
		Printer.printMessage("Enter service number");
		service.setServiceNumber(ScannerUtility.getInteger());
		
		Printer.printMessage("Enter service name");
		service.setName(ScannerUtility.getString());
		
		Printer.printMessage("Enter service price");
		service.setPrice(ScannerUtility.getDouble());
		
		Printer.printMessage("Enter if service is VIP(true/false)");
		service.setVip(ScannerUtility.getBoolean());
		
		Printer.printMessage("Enter beginning date of the service (dd-MM-yyyy)");
		service.setDateFrom(ScannerUtility.getDate());
		
		Printer.printMessage("Enter end date of the service (dd-MM-yyyy)");
		service.setDateTo(ScannerUtility.getDate());
		
		Printer.printMessage("Enter guest number who will be serviced");
		service.setGuestNumber(ScannerUtility.getInteger());
		
		Request request = new Request();
		request.setMethodName("addService");
		Object[] params = {service};
		request.setParams(params);
		ClientUtility.sendRequest(request);
		
		
		//controller.addService(service);
		
	}
	

}
