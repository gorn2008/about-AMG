package com.senla.ui.action.service;

import com.senla.ui.action.AbstractAction;
import com.senla.ui.util.ScannerUtility;

import api.core.server.Request;
import api.core.util.ClientUtility;
import api.core.util.Printer;


public class ChangeServicePriceAction extends AbstractAction {

	public void execute() {
		Printer.printMessage("Enter service number");
		Integer serviceNumber = ScannerUtility.getInteger();		
		
		Printer.printMessage("Enter new service price");
		Double newPrice = ScannerUtility.getDouble();
		
		Request request = new Request();
		request.setMethodName("changeServicePrice");
		Object[] params = {serviceNumber, newPrice};
		request.setParams(params);
		ClientUtility.sendRequest(request);
		
		//controller.changeServicePrice(serviceNumber, newPrice);
	}

}
