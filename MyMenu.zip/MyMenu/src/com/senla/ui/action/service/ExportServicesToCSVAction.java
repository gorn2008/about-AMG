package com.senla.ui.action.service;

import com.senla.ui.action.AbstractAction;

import api.core.server.Request;
import api.core.util.ClientUtility;


public class ExportServicesToCSVAction extends AbstractAction  {

	public void execute() {
		//controller.exportServicesToCSV();
		Request request = new Request();
		request.setMethodName("exportServicesToCSV");
		request.setParams(null);
		ClientUtility.sendRequest(request);
	}

}
