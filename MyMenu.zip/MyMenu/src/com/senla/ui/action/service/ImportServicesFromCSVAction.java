package com.senla.ui.action.service;

import com.senla.ui.action.AbstractAction;

import api.core.server.Request;
import api.core.util.ClientUtility;


public class ImportServicesFromCSVAction extends AbstractAction {

	public void execute() {
		//controller.importServicesFromCSV();
		Request request = new Request();
		request.setMethodName("importServicesFromCSV");
		request.setParams(null);
		ClientUtility.sendRequest(request);
	}

}
