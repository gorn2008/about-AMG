package com.senla.ui.action.service;

import java.util.List;

import com.senla.ui.action.AbstractAction;
import com.senla.ui.util.ScannerUtility;

import api.core.model.Service;
import api.core.server.Request;
import api.core.server.Response;
import api.core.util.ClientUtility;
import api.core.util.Printer;


public class ShowGuestServicesWithPricesSortedByDateAction extends AbstractAction {

	public void execute() {
		Printer.printMessage("Enter guest's number");
		Integer guestNumber = ScannerUtility.getInteger();
		
		
		Request request = new Request();
		request.setMethodName("getGuestServicesWithPricesSortedByDate");
		Object[] params = {guestNumber};
		request.setParams(params);
		Response response = ClientUtility.sendRequest(request);
		
		if (response.getResult() == null) {
			Printer.printMessage("Guest number " + guestNumber 
					+ "do not have services" );
			return;
		}
		List<Service> services = (List<Service>) response.getResult();		
		
		if (services.size() == 0) {
			Printer.printMessage("Guest number " + guestNumber 
					+ "do not have services" );
			return;
		}
		//List<Service> services = controller.getGuestServicesWithPricesSortedByDate(guestNumber);
		
		Printer.printMessage("List of guest's services sorted "
				+ " by date");
		for (Service service:services) {
			Printer.printService(service);
		}
		
	}

}

