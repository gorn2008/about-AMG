package com.senla.ui.action.service;

import java.util.List;

import com.senla.ui.action.AbstractAction;

import api.core.model.Service;
import api.core.server.Request;
import api.core.server.Response;
import api.core.util.ClientUtility;
import api.core.util.Printer;

public class ShowServicesPricesSortedByPriceAction extends AbstractAction {

	public void execute() {
		
		Request request = new Request();
		request.setMethodName("getServicesPricesSortedByPrice");
		request.setParams(null);
		Response response = ClientUtility.sendRequest(request);

		if (response.getResult() == null) {
			return;
		}
		Printer.printMessage("Prices of services sorted by price");
		List<Service> services = (List<Service>) response.getResult();
		
		//List<Service> services = controller.getServicesPricesSortedByPrice();
		for (Service service : services) {
			Printer.printServicePrice(service);
		}
	}

}
