package com.senla.ui.action.service;

import java.util.List;

import com.senla.ui.action.AbstractAction;

import api.core.model.Service;
import api.core.server.Request;
import api.core.server.Response;
import api.core.util.ClientUtility;
import api.core.util.Printer;

public class ShowServicesPricesSortedByVIPAction extends AbstractAction {

	public void execute() {
		Request request = new Request();
		request.setMethodName("getServicesPricesSortedByVIP");
		request.setParams(null);
		Response response = ClientUtility.sendRequest(request);

		if (response.getResult() == null) {
			return;
		}
		Printer.printMessage("Prices of services sorted by vip");
		List<Service> services = (List<Service>) response.getResult();
		for (Service service : services) {
			Printer.printServicePrice(service);
		}		
		
	/*	
		List<Service> services = controller.getServicesPricesSortedByVIP();
		if (services == null) {
			return;
		}
		Printer.printMessage("Prices of services sorted by vip");
		for (Service service : services) {
			Printer.printServicePrice(service);
		}*/
	}

}
