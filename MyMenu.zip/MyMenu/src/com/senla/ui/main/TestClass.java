package com.senla.ui.main;

import java.net.Socket;

import com.senla.ui.MenuController;

import api.core.client.Client;

public class TestClass {

	public static void main(String[] args) {
		Client client = new Client();
		Socket socket = client.connect();
		MenuController mc = new MenuController(socket);
		mc.run();		
	}

}
