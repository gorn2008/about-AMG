package com.senla.ui.util;

import java.util.Date;
import java.util.Scanner;

import api.core.util.DateUtility;
import api.core.util.Printer;

public class ScannerUtility {
	private static Scanner scanner = new Scanner(System.in);
	
	public static Integer getInteger() {
		Integer result = null;
		while (true) {
			String input = scanner.nextLine();
			try {
				result = Integer.parseInt(input);
				break;
			} catch (NumberFormatException e) {
				Printer.printMessage("The data entered is not Integer number."
						+ "Please enter Integer number.");
			}
		}
		return result;
	}
	
	public static Double getDouble() {
		Double result = null;
		while (true) {
			String input = scanner.nextLine();
			try {
				result = Double.parseDouble(input);
				break;
			} catch (NumberFormatException e) {
				Printer.printMessage("The data entered is not Double number."
						+ "Please enter Double number.");
			}
		}
		return result;
	}
	
	public static Byte getByte() {
		Byte result = null;
		while (true) {
			String input = scanner.nextLine();
			try {
				result = Byte.parseByte(input);
				break;
			} catch (NumberFormatException e) {
				Printer.printMessage("The data entered is not Byte number."
						+ "Please enter Byte number.");
			}
		}
		return result;
	}
	
	public static Boolean getBoolean() {
		String input = scanner.nextLine();
		return Boolean.parseBoolean(input);
	}
	
	public static Date getDate() {
		Date result = null;
		while (result == null) {
			String input = scanner.nextLine();
			result = DateUtility.getDate(input);
			if (result == null) {
				Printer.printMessage("The data entered is not Date."
						+ "Please enter Date in dd-MM-yyyy format.");
			}
		}
		return result;
	}
	
	public static String getString() {
		return scanner.nextLine();
	}
	
	public static Scanner getScanner() {
		return scanner;
	}
	
	public static void closeScanner() {
		scanner.close();
	}
	

}
